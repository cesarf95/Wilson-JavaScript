//Criar uma variável chamada 'nome' e mostrar no console: "Olá,meu nome é .....". Usando  templateString 

// let nome = 'Ygor';

// console.log(`Olá, meu nome é ${nome}`);

//Crie duas variáveis de números e mostre a soma 

// let num1 = 2;
// let num2 = 3;
// let result = num1 + num2 
// console.log(`A soma de ${num1} + ${num2} = ${result}`);
//ou
// console.log(`A soma de ${num1} + ${num2} = ${num1 + num2}`);

//Calcule o dobro de um número armazenado em uma variavel 
// let num1 = 300;

// let result = num1 * 2;

// console.log(`O dobro de ${num1} é:${result}`)

//Verifique se um número é par ou impar 
// let num1 = 4;
// if (num1 % 2 === 0) {
//         console.log(`O número ${num1} é:Par`)
//     }else{
//         console.log(`O número ${num1} é:Impar`)
//     }

//Verificar se uma pessoa é maior de idade 
// let idade = 25;
// if (idade >= 18){
//     console.log(`A pessoa com ${idade} anos já é maior de idade`)
// }else{
//     console.log(`A pessoa com ${idade} anos é menor de idade`)
// }
//operador ternpario ?:
// let idade1 = 17;
// let maioridade2 =  (idade1  >= 18) ? `A pessoa com ${idade1} anos já é maior de idade` :`A pessoa com ${idade1} anos é menor de idade`;
// console.log(maioridade2)







//Receba uma nota (0-10) e exiba: "Aprovado" >7,"Recuperação">= 5 || <= 6.9 ou "Reprovado" <4.9

// let nota = 3;
//  if (nota <= 4.9 && nota >= 0) {
//     console.log(`O aluno com a nota ${nota} está REPROVADO`)
//  }else if(nota >= 5 && nota <= 6.9){
//     console.log(`O aluno com a nota ${nota} está de RECUPERAÇÃO`)
//  }else if (nota >= 7 && nota <= 10){
//     console.log(`O aluno com a nota ${nota} está APROVADO`)
//  }else{
//     console.log(`Nota ivalida`)
//  }

